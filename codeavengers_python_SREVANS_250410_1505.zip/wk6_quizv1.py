
print("spanish quiz")
questions = [
  "",
  "",
  ""
  ]

answers = []